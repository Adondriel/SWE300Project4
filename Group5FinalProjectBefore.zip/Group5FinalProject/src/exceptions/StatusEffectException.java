package exceptions;
/**
 * @author Jason LoBianco
 */
public class StatusEffectException extends Exception
{
	public StatusEffectException(String message)
	{
		super(message); 
	}
}
