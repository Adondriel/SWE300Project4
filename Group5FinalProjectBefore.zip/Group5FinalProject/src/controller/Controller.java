package controller;
/**
 * The controller interface, the controllers test this already.
 * Does not need a separate test.
 * @author Adam Pine
 *
 */
public interface Controller {
	public void execute();
}
