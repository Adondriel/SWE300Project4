package command;

import pokemon.Pokemon;

/**
 * @author Bradley Solorzano
 * group 5 final project
 *
 */
public interface SwapCommand
{
	public void executeSwap(Pokemon selectedPokemon);
}
