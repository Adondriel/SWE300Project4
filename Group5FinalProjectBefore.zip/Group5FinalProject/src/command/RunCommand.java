package command;
/**
 * @author Bradley Solorzano
 * group 5 final project
 *
 */
public interface RunCommand
{
	public void executeRun();
}
